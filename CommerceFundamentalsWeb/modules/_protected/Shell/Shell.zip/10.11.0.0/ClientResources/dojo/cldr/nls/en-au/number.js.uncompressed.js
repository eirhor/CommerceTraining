define(
"dojo/cldr/nls/en-au/number", //begin v1.x content
{
	"currencyFormat": "¤#,##0.00"
}
//end v1.x content
);