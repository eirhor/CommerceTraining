define(
"dojo/cldr/nls/ar/currency", //begin v1.x content
{
	"HKD_displayName": "دولار هونج كونج",
	"CHF_displayName": "فرنك سويسري",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "دولار كندي",
	"HKD_symbol": "HK$",
	"CNY_displayName": "يوان صيني",
	"USD_symbol": "US$",
	"AUD_displayName": "دولار أسترالي",
	"JPY_displayName": "ين ياباني",
	"CAD_symbol": "CA$",
	"USD_displayName": "دولار أمريكي",
	"EUR_symbol": "€",
	"CNY_symbol": "ي.ص",
	"GBP_displayName": "جنيه إسترليني",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "يورو"
}
//end v1.x content
);