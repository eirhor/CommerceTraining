define(
"dojo/cldr/nls/fi/currency", //begin v1.x content
{
	"HKD_displayName": "Hongkongin dollari",
	"CHF_displayName": "Sveitsin frangi",
	"JPY_symbol": "¥",
	"CAD_displayName": "Kanadan dollari",
	"HKD_symbol": "HKD",
	"CNY_displayName": "Kiinan yuan",
	"USD_symbol": "$",
	"AUD_displayName": "Australian dollari",
	"JPY_displayName": "Japanin jeni",
	"CAD_symbol": "CAD",
	"USD_displayName": "Yhdysvaltain dollari",
	"EUR_symbol": "€",
	"CNY_symbol": "CNY",
	"GBP_displayName": "Englannin punta",
	"GBP_symbol": "£",
	"AUD_symbol": "AUD",
	"EUR_displayName": "euro"
}
//end v1.x content
);